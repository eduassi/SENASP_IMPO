var animation = bodymovin.loadAnimation({
  container: document.getElementById("infograficoAnimado"),
  renderer: "svg",
  loop: false,
  autoplay: true,
  path: "assets/images/module_1/infografico/infografico_1.json"
});
